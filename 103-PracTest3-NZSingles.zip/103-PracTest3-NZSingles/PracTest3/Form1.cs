﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace PracTest3 //Singles
{
    public partial class Form1 : Form
    {
        //Name :
        //ID No:

        public Form1()
        {
            InitializeComponent();
        }

        //the width and height of an icon
        const int ICON_SIZE = 14;
     
        /// <summary>
        /// Draws an icon representing rising on the Graphics object specified.
        /// It fills an up triangle at position (x,y) in green with a black outline.
        /// Uses the ICON_SIZE constant for the size of the triangle.
        /// </summary>
        /// <param name="paper">The Graphics object to draw on.</param>
        /// <param name="x">The x position of the top left corner of the triangle.</param>
        /// <param name="y">The y position of the top left corner of the triangle.</param>
        private void Rising(Graphics paper, int x, int y)
        {
            //define a triangle pointing upwards
            Point[] triangle = new Point[3] { new Point(x + ICON_SIZE / 2, y), new Point(x, y + ICON_SIZE), new Point(x + ICON_SIZE, y + ICON_SIZE) };
            //fill triangle with green 
            paper.FillPolygon(Brushes.Chartreuse, triangle);
            //draw outline in black
            paper.DrawPolygon(Pens.Black, triangle);
        }

        /// <summary>
        /// Draws an icon representing falling on the Graphics object specified.
        /// It fills a down triangle at position (x,y) in red with a black outline.
        /// Uses the ICON_SIZE constant for the size of the triangle.
        /// </summary>
        /// <param name="paper">The Graphics object to draw on.</param>
        /// <param name="x">The x position of the top left corner of the triangle.</param>
        /// <param name="y">The y position of the top left corner of the triangle.</param>
        private void Falling(Graphics paper, int x, int y)
        {
            //define a triangle pointing down
            Point[] triangle = new Point[3] { new Point(x, y), new Point(x+ ICON_SIZE, y ), new Point(x + ICON_SIZE/2, y + ICON_SIZE) };
            //fill triangle with red 
            paper.FillPolygon(Brushes.Red, triangle);
            //draw outline in black
            paper.DrawPolygon(Pens.Black, triangle);
        }

        /// <summary>
        /// Draws an icon representing static on the Graphics object specified.
        /// It fills a square at position (x,y) in blue with a black outline.
        /// Uses the ICON_SIZE constant for the size of the square.
        /// </summary>
        /// <param name="paper">The Graphics object to draw on.</param>
        /// <param name="x">The x position of the top left corner of the square.</param>
        /// <param name="y">The y position of the top left corner of the square.</param>
        private void Stable(Graphics paper, int x, int y)
        {
            //define a square
            Rectangle square = new Rectangle(x, y, ICON_SIZE, ICON_SIZE);
            //fill square with green 
            paper.FillRectangle(Brushes.CornflowerBlue, square);
            //draw outline in black
            paper.DrawRectangle(Pens.Black, square);
        }
      
    }
}
