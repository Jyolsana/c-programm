﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalTest1
{
    public partial class Form1 : Form
    {
        //Name:
        //ID:

        //The cost of a single 0.75 carat diamond
        const decimal DIAMOND_COST = 1200;
        //The cost of 1 gram of 24K gold
        const decimal GOLD_COST = 55.34m;
        //The profit margin (80%)
        const double PROFIT_MARGIN = 0.8;

        public Form1()
        {
            InitializeComponent();
        }
    }
}
