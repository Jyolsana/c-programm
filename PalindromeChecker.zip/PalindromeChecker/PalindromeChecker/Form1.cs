namespace PalindromeChecker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string potentialPalindrome = textBox1.Text;
            int left = 0;
            int right = potentialPalindrome.Length - 1;
            Boolean isPalindrome = true;
            while (left < right)
            {
                // Only consider actual letters occurring in the string (not commas or whitespace, for example)
                if (!Char.IsLetter(potentialPalindrome[left])) {
                    left++;
                    continue; // Continue to the next iteration of the loop and don't execute the rest of the body
                }
                if (!Char.IsLetter(potentialPalindrome[right]))
                {
                    right--;
                    continue; // Continue to the next iteration of the loop and don't execute the rest of the body
                }
                if (potentialPalindrome[left] != potentialPalindrome[right])
                {
                    isPalindrome = false;
                    break;
                }
                left++;
                right--;
            }
            if (isPalindrome)
            {
                MessageBox.Show("This is indeed a palindrome.");
            } else
            {
                MessageBox.Show("This is not a palindrome.");
            }
         }
    }
}