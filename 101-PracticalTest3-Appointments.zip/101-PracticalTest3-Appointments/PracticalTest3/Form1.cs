﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PracticalTest3
{
    public partial class Form1 : Form
    {
        //Name: Jyolsana Thekkekara Tony
        //ID: 1638491

        //The number of days in the calendar, 1 is Monday and 5 is Friday
        const int NUM_DAYS = 5;
        //The number of hours to display for each day
        const int NUM_HOURS = 10;
        //The starting hour for the calendar (9am)
        const int START_HOUR = 9;
        //The amount of gap between the text and outline of an appointment
        const int OFFSET = 2;
        //The width of an appointment
        const int APP_WIDTH = 100;
        //The height of an appointment
        const int APP_HEIGHT = 60;

        //Colour variables for the different appointments
        Color WORK_COLOUR = Color.Gold;
        Color PERSONAL_COLOUR = Color.LightBlue;

        const string Filter = "CSV Files|*.csv|All Files|*.*";

        //Create List to store data from the file
        List<String> DayList = new List<string>();
        List<int> HourList = new List<int>();
        List<String> Appoinment_TypeList = new List<string>();
        List<String> DescriptionList = new List<String>();

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Draws the given text at the specified x and y coordinates
        /// </summary>
        /// <param name="paper">Where to draw the text</param>
        /// <param name="hour">The hour of the appointment</param>
        /// <param name="text">The text of the appointment</param>
        /// <param name="x">The x position of the appointment</param>
        /// <param name="y">The y position of the appointment</param>
        private void DrawText(Graphics paper, int hour, string text, int x, int y)
        {
            paper.DrawString(hour.ToString() + ".00: " + text, new Font("Arial", 8),
                Brushes.Black, x + OFFSET, y + OFFSET);

        }

        /// <summary>
        /// Draws an appointment in the given color.
        /// </summary>
        /// <param name="paper">Where to draw the appointment</param>
        /// <param name="x">The x position of the appointment</param>
        /// <param name="y">The y position of the appointment</param>
        /// <param name="backColor">The background color of the appointment</param>
        private void DrawAppointment(Graphics paper, int x, int y, Color backColor)
        {
            SolidBrush br = new SolidBrush(backColor);
            Pen pen1 = new Pen(Color.Black, 1);

            paper.FillRectangle(br, x, y, APP_WIDTH, APP_HEIGHT);
            paper.DrawRectangle(pen1, x, y, APP_WIDTH, APP_HEIGHT);


        }

        /// <summary>
        /// Draws an empty calendar.
        /// </summary>
        /// <param name="paper">Where to draw the calendar</param>
        private void DrawEmptyCalendar(Graphics paper)
        {
            //The x position of the current appointment
            int x = 0;
            //The y position of the current appointment
            int y = 0;

            //Clear the drawing area
            pictureBoxCalendar.Refresh();

            //Loop for each day in the calendar
            for (int hour = 1; hour <= NUM_HOURS; hour++)
            {
                //Loop for each hour in the calendar
                for (int day = 1; day <= NUM_DAYS; day++)
                {
                    //Draw the appointment and then move to the next position
                    DrawAppointment(paper, x, y, Color.White);
                    x += APP_WIDTH;
                }

                //Move down to the next row and move back to beginning of the row
                y += APP_HEIGHT;
                x = 0;
            }
        }

        /// <summary>
        /// Calculate the x position of an appointment.
        /// </summary>
        /// <param name="day">The day of the appointment</param>
        /// <returns>The x position of the appointment based on the given day</returns>
        private int CalculateX(string day)
        {
            //Stores all the days to display on the calendar
            string[] dayArray = new string[] { "Mon", "Tue", "Wed", "Thu", "Fri" };
            //The x position of the appointment
            int x = 0;

            //The number for a day, Mon = 0, Fri = 4
            int dayNum = 0;

            //Look through the array for the given day
            for (int i = 0; i < dayArray.Length; i++)
            {
                //Check if the current day matches the given day
                if (dayArray[i] == day)
                {
                    //Store the day number for the given day
                    dayNum = i;
                }
            }

            //Calculate the x position of the appointment depending on the day
            x = dayNum * APP_WIDTH;

            return x;
        }
        /// <summary>
        /// Calculate the y position of an appointment.
        /// </summary>
        /// <param name="day"></param>
        /// <returns>The y position of the appointment based on the given day</returns>
        private int CalculateY(int hour)
        {
            int y = 0;
            y = (hour - START_HOUR) * APP_HEIGHT;
            return y;

        }
   

            /// <summary>
            /// Exits from the Application
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        /// <summary>
        /// Read a csv line from the file
        /// Split the line storing the values into an array
        /// IF array has correct number of elements THEN
        ///  Extract values from array into seperate variables
        ///   Display the values into the Listbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics paper = pictureBoxCalendar.CreateGraphics();
            StreamReader reader;
            String line = "";
            String[] csvArray;
            String Day = "";
            int hour = 0;
            String Appoinment_Type = "";
            String Description = "";
            int x = 0;
            int y = 0;

            //Set the dialog filter
            openFileDialog1.Filter = Filter;
            //Check the file has been selected
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //open selected file
                reader = File.OpenText(openFileDialog1.FileName);

                // While not the end of file
                while (!reader.EndOfStream)
                {
                    try
                    {
                        //Read the csv from the file 
                        line = reader.ReadLine();
                        //Split the line storing the values into an array
                        csvArray = line.Split(',');
                        // Check the array have correct amount of elements
                        if (csvArray.Length == 4)
                        {
                            Day = csvArray[0];
                            hour = int.Parse(csvArray[1]);
                            Appoinment_Type = csvArray[2];
                            Description = csvArray[3];

                            //Display the values into List Box
                            listBoxCalendar.Items.Add(Day.PadRight(10) + hour.ToString().PadRight(10) +
                                Appoinment_Type.PadRight(30) + Description);

                            //Add the data to the list
                            DayList.Add(Day);
                            HourList.Add(hour);
                            Appoinment_TypeList.Add(Appoinment_Type);
                            DescriptionList.Add(Description);

                            //Calculate the X  and Y position of the Calender Appoinment
                            x = CalculateX(Day);
                            y = CalculateY(hour);

                            //if(Appoinment_Type=)
                            //Draw the Calender
                            //DrawAppointment(paper, x, y, Color.Black);
                            
                            if (Appoinment_Type=="Work")
                            {
                                Color backcolor = WORK_COLOUR;
                                DrawAppointment(paper, x, y, backcolor);
                                

                            }
                            else if(Appoinment_Type == "Personal")
                            {
                                Color backcolor = PERSONAL_COLOUR;
                                DrawAppointment(paper, x, y, backcolor);

                            }
                            else
                            {
                                DrawEmptyCalendar(paper);
                            }

                        }

                        else
                        {
                            Console.WriteLine("Error: " + line);

                        }
                        

                    }
                    catch
                    {
                        Console.WriteLine("Error: " + line);

                    }


                }
                reader.Close();
            }
        }

       
        /// <summary>
        /// Calculates the total Appoinments in the calender and diplays the value
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void showCalenderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int workcount = 0;
            int personalcount = 0;
            String count = txt_app_count.Text;
            int sum = 0;
            for(int i =0; i < Appoinment_TypeList.Count; i++)
            {
                if(count == "Work")
                {
                   sum= workcount++;
                }
                else
                {

                  sum=  personalcount++;
                }
            }

            MessageBox.Show(sum.ToString());




        }
    }
}
