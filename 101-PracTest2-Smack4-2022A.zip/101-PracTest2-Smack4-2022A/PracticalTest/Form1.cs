﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalTest
{
    public partial class Form1 : Form
    {
        //The width and height of each square
        const int SQUARE_SIZE = 50;
   

        public Form1()
        {
            InitializeComponent();
        }

        

        
    }
}
