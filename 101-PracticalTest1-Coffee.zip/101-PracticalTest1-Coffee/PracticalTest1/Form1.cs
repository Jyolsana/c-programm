﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalTest1
{
    public partial class Form1 : Form
    {
        //Name:
        //Student ID:

        //Assuming everyone drinks two cups per day for 5 days (i.e. morning and afternoon tea/coffee break)
        const int CUPS_PER_WEEK = 10;
        //Average amount of coffee grounds required to make a cup of coffee
        //Assume this is also the amount of beans required, i.e. no wastage when grinding
        const double COFFEE_GROUNDS_PER_CUP = 0.015;
        //Cost of a 1kg bag of coffee beans is $25.00
        const decimal COFFEE_COST = 25m;
        //Cost of a box of 100 teabags is $4.50
        const decimal TEA_COST = 4.50m;


        public Form1()
        {
            InitializeComponent();
        }
    }
}
